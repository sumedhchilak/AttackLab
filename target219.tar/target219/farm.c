/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_460()
{
    return 773768024U;
}

unsigned getval_224()
{
    return 2425387217U;
}

void setval_426(unsigned *p)
{
    *p = 3284633928U;
}

unsigned addval_172(unsigned x)
{
    return x + 2423789284U;
}

unsigned addval_188(unsigned x)
{
    return x + 2428995912U;
}

void setval_292(unsigned *p)
{
    *p = 2496104776U;
}

unsigned addval_346(unsigned x)
{
    return x + 2421737872U;
}

void setval_117(unsigned *p)
{
    *p = 2496104776U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_283()
{
    return 3348156041U;
}

unsigned getval_113()
{
    return 2430634312U;
}

void setval_232(unsigned *p)
{
    *p = 3223372417U;
}

unsigned getval_449()
{
    return 2429452774U;
}

void setval_448(unsigned *p)
{
    *p = 2429667651U;
}

void setval_174(unsigned *p)
{
    *p = 3531918985U;
}

unsigned getval_166()
{
    return 3674784392U;
}

unsigned getval_312()
{
    return 3524838025U;
}

unsigned getval_219()
{
    return 465817097U;
}

unsigned addval_215(unsigned x)
{
    return x + 3269495112U;
}

unsigned getval_122()
{
    return 2497743176U;
}

void setval_401(unsigned *p)
{
    *p = 3372798345U;
}

unsigned getval_387()
{
    return 3286272344U;
}

void setval_443(unsigned *p)
{
    *p = 3524838025U;
}

void setval_383(unsigned *p)
{
    *p = 2425406089U;
}

unsigned addval_367(unsigned x)
{
    return x + 2464188744U;
}

void setval_111(unsigned *p)
{
    *p = 3678982537U;
}

unsigned getval_239()
{
    return 3286272329U;
}

void setval_126(unsigned *p)
{
    *p = 3372273289U;
}

void setval_477(unsigned *p)
{
    *p = 3372798347U;
}

void setval_282(unsigned *p)
{
    *p = 3373846153U;
}

unsigned addval_314(unsigned x)
{
    return x + 3767093422U;
}

void setval_112(unsigned *p)
{
    *p = 3263813307U;
}

void setval_133(unsigned *p)
{
    *p = 2425475465U;
}

void setval_455(unsigned *p)
{
    *p = 3683963273U;
}

unsigned getval_150()
{
    return 3268512181U;
}

void setval_454(unsigned *p)
{
    *p = 3677933961U;
}

unsigned addval_251(unsigned x)
{
    return x + 3234120329U;
}

unsigned addval_194(unsigned x)
{
    return x + 3229929129U;
}

void setval_329(unsigned *p)
{
    *p = 3380924041U;
}

unsigned addval_136(unsigned x)
{
    return x + 3529556617U;
}

void setval_145(unsigned *p)
{
    *p = 3286272344U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
